#include <stdio.h>

int somaDigitos(int n) {

    if (n == 0) {
        return 0;
    }
    
    return (n % 10) + somaDigitos(n / 10);
}

int main() {
    int numero;
    
    printf("Digite um número inteiro: ");
    scanf("%d", &numero);
    

    if (numero < 0) {
        numero = -numero;
    }
    
    int resultado = somaDigitos(numero);
    printf("A soma dos dígitos de %d é: %d\n", numero, resultado);
    
    return 0;
}